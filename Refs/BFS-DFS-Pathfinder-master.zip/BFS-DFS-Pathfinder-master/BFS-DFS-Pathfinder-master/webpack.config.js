module.exports = {
  entry: "./lib/maze.js",
  output: {
  	filename: "./lib/bundle.js"
  },
  devtool: 'source-map',
};
